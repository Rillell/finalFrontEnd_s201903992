# Vue2.X 기본 템플릿
## 초기화
- 초기화 : `npm install --no-audit --no-fund`

## 추가 설치 패키지
- vue

__- `npm i vue --no-audit –no-fund`__

- vue-loader@next
- vue-style-loader
- @vue/compiler-sfc
 
__- `npm i -D vue-loader vue-style-loader @vue/compiler-sfc --no-audit --no-fund`__


## 사용방법
- 개발용 : `npm run dev`
- 운영용 : `npm run buld`


## 주의사항!
-  @vue/compiler-sfc run 오류시 :  `npm i --include=dev  vue-template-compiler`로 설치<br>
