<template>
  <h1>{{message}}</h1>
</template>

<script>
export default {
  data() {
    return {
      message: 'Hello Vue!!'
    }
  },
}
</script>