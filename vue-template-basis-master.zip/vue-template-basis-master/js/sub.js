export function double(number) {
  return number * 2
}